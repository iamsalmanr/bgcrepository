<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

$log = [];

$accounts = [
    [
        'email' => 'superadmin@bgcbd.com',
        'name' => 'Super Admin',
        'role' => 'super_admin',
        'is_superadmin' => 1,
    ],
    [
        'email' => 'member@bgcbd.com',
        'name' => 'Member User',
        'role' => 'member',
        'is_superadmin' => 0,
    ],
    [
        'email' => 'admin@bgcbd.com',
        'name' => 'Admin',
        'role' => 'admin',
        'is_superadmin' => 0,
    ],
    [
        'email' => 'superadmin@bgc.com',
        'name' => 'Super Admin (BGC)',
        'role' => 'super_admin',
        'is_superadmin' => 1,
    ],
    [
        'email' => 'user@bgc.com',
        'name' => 'Demo User (BGC)',
        'role' => 'member',
        'is_superadmin' => 0,
    ],
];

foreach ($accounts as $acc) {
    $user = User::where('email', $acc['email'])->first();
    if (!$user) {
        $user = new User();
        $user->email = $acc['email'];
    }
    $user->name = $acc['name'];
    // In Laravel 11 with 'password' => 'hashed' in casts, setting plain 'password' handles hashing automatically.
    // However, assigning Hash::make('password') if cast is active might double-hash or work if cast is direct.
    // To be 100% resilient across both cast & direct queries:
    $user->password = 'password';
    $user->role = $acc['role'];
    $user->is_superadmin = $acc['is_superadmin'];
    $user->email_verified_at = now();
    $user->save();

    // Verify authentication immediately
    $authCheck = Auth::attempt(['email' => $acc['email'], 'password' => 'password']);
    $log[] = "{$acc['email']} saved -> Auth check: " . ($authCheck ? "SUCCESS" : "FAILED (Hash mismatch)");
}

$allUsers = User::select('id', 'name', 'email', 'role', 'is_superadmin')->get()->toArray();

echo "DEMO SEED RESULTS:\n";
echo implode("\n", $log) . "\n\n";
echo "DATABASE USERS:\n";
print_r($allUsers);
