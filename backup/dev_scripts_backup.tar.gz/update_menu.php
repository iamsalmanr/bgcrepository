<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

// Fix spelling
\App\Models\MenuItem::whereIn('id', [22, 44])->update(['title' => 'Upcoming Tournaments']);

$newItems = [
    ['title' => 'Tournament Results', 'url' => '/tournament-result', 'target' => '_self'],
    ['title' => 'List of Winners', 'url' => '/list-of-winner', 'target' => '_self'],
    ['title' => 'Hole in One Record', 'url' => '/hole-in-one-record', 'target' => '_self'],
    ['title' => 'Flight Schedule', 'url' => '/flight-schedule', 'target' => '_self'],
];

// Add to top_bar
$parentTop = \App\Models\MenuItem::find(20);
if ($parentTop) {
    // Delete existing ones just in case script is run multiple times
    \App\Models\MenuItem::where('parent_id', 20)->whereNotIn('id', [21, 22])->delete();

    $order = 2;
    foreach ($newItems as $item) {
        \App\Models\MenuItem::create([
            'menu_id' => 2,
            'parent_id' => 20,
            'title' => $item['title'],
            'url' => $item['url'],
            'target' => $item['target'],
            'order' => $order++,
        ]);
    }
}

// Add to mobile_hamburger
$parentMobile = \App\Models\MenuItem::find(42);
if ($parentMobile) {
    \App\Models\MenuItem::where('parent_id', 42)->whereNotIn('id', [43, 44])->delete();
    
    $order = 2;
    foreach ($newItems as $item) {
        \App\Models\MenuItem::create([
            'menu_id' => 4,
            'parent_id' => 42,
            'title' => $item['title'],
            'url' => $item['url'],
            'target' => $item['target'],
            'order' => $order++,
        ]);
    }
}

echo "Menu updated successfully.\n";
