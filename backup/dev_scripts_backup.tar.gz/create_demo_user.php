<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;

// Create demo user
$user = User::firstOrCreate(
    ['email' => 'user@bgc.com'],
    [
        'name' => 'Demo User',
        'password' => bcrypt('password'),
        'role' => 'user',
    ]
);

echo "User: " . $user->email . " (role: " . $user->role . ")\n";

// Check admin
$admin = User::where('email', 'superadmin@bgc.com')->first();
if ($admin) {
    echo "Admin: " . $admin->email . " (role: " . $admin->role . ")\n";
} else {
    echo "Admin not found, creating...\n";
    User::create([
        'name' => 'Super Admin',
        'email' => 'superadmin@bgc.com',
        'password' => bcrypt('password'),
        'is_superadmin' => true,
        'role' => 'super_admin',
    ]);
}

echo "Done!\n";
