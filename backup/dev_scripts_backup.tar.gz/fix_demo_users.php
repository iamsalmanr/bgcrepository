<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

// Ensure superadmin
$admin = User::where('email', 'superadmin@bgc.com')->first();
if (!$admin) {
    $admin = new User();
    $admin->email = 'superadmin@bgc.com';
    $admin->name = 'Super Admin';
}
$admin->password = Hash::make('password');
$admin->is_superadmin = true;
$admin->role = 'super_admin';
$admin->email_verified_at = now();
$admin->save();
echo "Admin configured: superadmin@bgc.com / password (verified)\n";

// Ensure regular user
$user = User::where('email', 'user@bgc.com')->first();
if (!$user) {
    $user = new User();
    $user->email = 'user@bgc.com';
    $user->name = 'Demo User';
}
$user->password = Hash::make('password');
$user->role = 'user';
$user->email_verified_at = now();
$user->save();
echo "User configured: user@bgc.com / password (verified)\n";
