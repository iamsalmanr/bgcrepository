<?php
require 'vendor/autoload.php';
$app = require_once 'bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

try {
    \App\Models\User::factory()->create([
        'name' => 'Publish Command Tester',
        'email' => 'publish-test@biolink.by',
        'password' => bcrypt('password123')
    ]);
    echo "User created successfully.\n";
} catch (\Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
