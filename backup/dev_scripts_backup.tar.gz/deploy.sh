#!/bin/bash
echo "Starting deployment process..."

# Pull latest changes
git pull origin main

echo "Extracting database credentials from .env..."
# Extract DB credentials safely
DB_USER=$(grep -E '^DB_USERNAME=' .env | cut -d '=' -f2 | tr -d '"' | tr -d '\r')
DB_PASS=$(grep -E '^DB_PASSWORD=' .env | cut -d '=' -f2 | tr -d '"' | tr -d '\r')
DB_NAME=$(grep -E '^DB_DATABASE=' .env | cut -d '=' -f2 | tr -d '"' | tr -d '\r')

echo "Importing latest database backup..."
if [ -z "$DB_PASS" ]; then
    mysql -u "$DB_USER" "$DB_NAME" < backup/latest_db_backup.sql
else
    mysql -u "$DB_USER" -p"$DB_PASS" "$DB_NAME" < backup/latest_db_backup.sql
fi

echo "Installing node dependencies and building..."
npm install
npm run build

echo "Optimizing Laravel cache and setting permissions..."
php artisan config:cache
php artisan route:cache
php artisan view:cache
php artisan storage:link
chmod -R a+rX public
chmod -R 777 storage bootstrap/cache
sudo /usr/local/lsws/bin/lswsctrl restart

echo "Deployment completed successfully!"
