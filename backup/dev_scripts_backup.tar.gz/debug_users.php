<?php
require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\User;
use Illuminate\Support\Facades\Hash;

echo "=== ALL USERS IN DB ===\n";
foreach (User::all() as $u) {
    echo "ID: {$u->id} | Email: '{$u->email}' | Name: '{$u->name}' | Role: '{$u->role}'\n";
    if (Hash::check('password', $u->password)) {
        echo "   -> Password 'password' MATCHES!\n";
    } else {
        echo "   -> Password 'password' DOES NOT MATCH!\n";
    }
}
