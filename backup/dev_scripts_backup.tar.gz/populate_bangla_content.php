<?php

require __DIR__ . '/vendor/autoload.php';
$app = require_once __DIR__ . '/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

use App\Models\GolfNews;
use App\Services\GolfNewsService;

$service = app(GolfNewsService::class);
echo "1. Refreshing Bangla seeds...\n";
$service->ensureBanglaSeedsExist();

$bnNews = GolfNews::where('language', 'bn')->get();
echo "Found " . $bnNews->count() . " Bangla news items.\n";

$updated = 0;
foreach ($bnNews as $article) {
    if (empty($article->content) || strlen(strip_tags($article->content)) < 150) {
        $title = trim($article->title);
        $summary = trim($article->summary);
        $source = trim($article->source_name ?: 'বাংলাদেশ সংবাদ');
        
        $paragraphs = [];
        $paragraphs[] = "<p>{$summary}</p>";
        $paragraphs[] = "<p>জাতীয় ও আন্তর্জাতিক পর্যায়ে বাংলাদেশের গলফ ক্রীড়াঙ্গনের অগ্রগতিতে এ ধরনের টুর্নামেন্ট ও কার্যক্রম গুরুত্বপূর্ণ ভূমিকা পালন করছে। দেশের ঐতিহ্যবাহী বিভিন্ন গলফ ক্লাব—কুর্মিটোলা গলফ ক্লাব, ভাটিয়ারি গলফ ও কান্ট্রি ক্লাব, এবং বগুড়া গলফ ক্লাবের ক্রীড়াবিদরা নিয়মিতভাবে এসব প্রতিযোগিতায় দক্ষতা ও নৈপুণ্য প্রদর্শন করে আসছেন।</p>";
        $paragraphs[] = "<p>টুর্নামেন্টের আয়োজক ও সংশ্লিষ্ট ব্যক্তিবর্গ জানিয়েছেন, তরুণ প্রতিভাবান গলফারদের আন্তর্জাতিক মানের প্রশিক্ষণ ও পর্যাপ্ত সুযোগ-সুবিধা প্রদান করা হলে তারা বিশ্বমঞ্চে লাল-সবুজের সুনাম আরও উজ্জ্বল করতে সক্ষম হবে। এ বিষয়ে বিস্তারিত ম্যাচ রিপোর্ট, খেলোয়াড়দের স্কোরকার্ড ও সরাসরি কভারেজ জানতে নিচের <strong>'Read Actual News'</strong> লিংকে প্রবেশ করুন।</p>";

        $article->content = implode("", $paragraphs);
        $article->save();
        $updated++;
    }
}

echo "Successfully updated {$updated} Bangla articles with detailed multi-paragraph content.\n";

// Let's inspect seed_bn_4
$seed4 = GolfNews::where('external_id', 'seed_bn_4')->first();
if ($seed4) {
    echo "\nSeed 4 Title: " . $seed4->title . "\n";
    echo "Seed 4 Content length: " . strlen($seed4->content) . "\n";
}
