@echo off
echo ========================================================
echo                 Publishing Application
echo ========================================================

echo.
echo [1/4] Dumping local database...
if not exist backup mkdir backup
C:\laragon\bin\mysql\mysql-8.4.3-winx64\bin\mysqldump.exe -u root bgc > backup\latest_db_backup.sql

echo.
echo [2/4] Committing to Git...
git add .
git commit -m "Auto publish"
git push origin main

echo.
echo [3/4] Connecting to remote server and deploying...
wsl ssh -o StrictHostKeyChecking=no server@203.202.255.98 "cd /home/bgcbd.com && git pull origin main && bash deploy.sh"

echo.
echo [4/4] Done!

