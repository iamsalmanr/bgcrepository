const fs = require('fs');
const path = require('path');

const modules = [
    {
        name: 'Results',
        singular: 'Result',
        model: 'TournamentResult',
        routePrefix: 'tournament-results',
        fields: [
            { key: 'name', label: 'Name', type: 'text' },
            { key: 'sponsored_by', label: 'Sponsored By', type: 'text' },
            { key: 'date', label: 'Date', type: 'date' },
        ],
        hasFile: true
    },
    {
        name: 'HoleInOnes',
        singular: 'Hole In One Record',
        model: 'HoleInOne',
        routePrefix: 'hole-in-ones',
        fields: [
            { key: 'name', label: 'Name', type: 'text' },
            { key: 'hole_no', label: 'Hole No', type: 'text' },
            { key: 'date', label: 'Date', type: 'date' },
        ],
        hasFile: false
    },
    {
        name: 'Winners',
        singular: 'Winner List',
        model: 'WinnerList',
        routePrefix: 'winner-lists',
        fields: [
            { key: 'title', label: 'Title', type: 'text' },
            { key: 'date', label: 'Date', type: 'date' },
        ],
        hasFile: true
    },
    {
        name: 'FlightSchedules',
        singular: 'Flight Schedule',
        model: 'FlightSchedule',
        routePrefix: 'flight-schedules',
        fields: [
            { key: 'title', label: 'Title', type: 'text' },
            { key: 'date', label: 'Date', type: 'date' },
        ],
        hasFile: true
    }
];

const getIndexTemplate = (mod) => `import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import { Plus, Edit2, Trash2, FileText } from 'lucide-react';
import Pagination from '@/Components/Pagination';

export default function Index({ records }) {
    const { delete: destroy } = useForm();

    const handleDelete = (id) => {
        if (confirm('Are you sure you want to delete this record?')) {
            destroy(route('${mod.routePrefix}.destroy', id));
        }
    };

    return (
        <AuthenticatedLayout header="Manage ${mod.name}">
            <Head title="${mod.name}" />

            <div className="sm:flex sm:items-center">
                <div className="sm:flex-auto">
                    <p className="mt-2 text-sm text-gray-700">A list of all ${mod.name.toLowerCase()}.</p>
                </div>
                <div className="mt-4 sm:ml-16 sm:mt-0 sm:flex-none">
                    <Link href={route('${mod.routePrefix}.create')} className="block rounded-md bg-emerald-600 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-emerald-500 flex items-center">
                        <Plus className="h-4 w-4 mr-1" /> Add ${mod.singular}
                    </Link>
                </div>
            </div>

            <div className="mt-8 flow-root">
                <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                        <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                            <table className="min-w-full divide-y divide-gray-300">
                                <thead className="bg-gray-50">
                                    <tr>
                                        ${mod.fields.map(f => `<th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">${f.label}</th>`).join('\\n                                        ')}
                                        ${mod.hasFile ? `<th scope="col" className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900">File</th>` : ''}
                                        <th scope="col" className="relative py-3.5 pl-3 pr-4 sm:pr-6"><span className="sr-only">Actions</span></th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200 bg-white">
                                    {records.data.map((record) => (
                                        <tr key={record.id}>
                                            ${mod.fields.map(f => `<td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{record.${f.key}}</td>`).join('\\n                                            ')}
                                            ${mod.hasFile ? `<td className="whitespace-nowrap px-3 py-4 text-sm text-gray-500">{record.file_path ? <a href={\`/storage/\${record.file_path}\`} target="_blank" className="text-emerald-600 hover:underline flex items-center"><FileText className="w-4 h-4 mr-1"/> View Detail</a> : '-'}</td>` : ''}
                                            <td className="relative whitespace-nowrap py-4 pl-3 pr-4 text-right text-sm font-medium sm:pr-6">
                                                <div className="flex justify-end gap-3">
                                                    <Link href={route('${mod.routePrefix}.edit', record.id)} className="text-indigo-600 hover:text-indigo-900"><Edit2 className="h-4 w-4" /></Link>
                                                    <button onClick={() => handleDelete(record.id)} className="text-red-600 hover:text-red-900"><Trash2 className="h-4 w-4" /></button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            {records.links && <div className="mt-4"><Pagination links={records.links} /></div>}
        </AuthenticatedLayout>
    );
}
`;

const getCreateTemplate = (mod) => `import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import InputError from '@/Components/InputError';
import InputLabel from '@/Components/InputLabel';
import PrimaryButton from '@/Components/PrimaryButton';
import TextInput from '@/Components/TextInput';

export default function Create() {
    const { data, setData, post, processing, errors } = useForm({
        ${mod.fields.map(f => `${f.key}: '',`).join('\\n        ')}
        ${mod.hasFile ? `file: null,` : ''}
    });

    const submit = (e) => {
        e.preventDefault();
        post(route('${mod.routePrefix}.store'));
    };

    return (
        <AuthenticatedLayout header="Add New ${mod.singular}">
            <Head title="Add ${mod.singular}" />

            <div className="max-w-2xl mx-auto mt-6 px-4 sm:px-6 lg:px-8">
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div className="p-6 text-gray-900">
                        <form onSubmit={submit} className="space-y-6">
                            ${mod.fields.map(f => `<div>
                                <InputLabel htmlFor="${f.key}" value="${f.label}" />
                                <TextInput
                                    id="${f.key}"
                                    type="${f.type}"
                                    value={data.${f.key}}
                                    className="mt-1 block w-full"
                                    onChange={(e) => setData('${f.key}', e.target.value)}
                                    required={${f.key === 'name' || f.key === 'title' || f.key === 'hole_no' ? 'true' : 'false'}}
                                />
                                <InputError message={errors.${f.key}} className="mt-2" />
                            </div>`).join('\\n                            ')}
                            
                            ${mod.hasFile ? `<div>
                                <InputLabel htmlFor="file" value="Attachment (PDF/Image)" />
                                <input
                                    id="file"
                                    type="file"
                                    onChange={(e) => setData('file', e.target.files[0])}
                                    className="mt-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 border border-slate-200 rounded-md p-1"
                                    accept=".pdf,image/*"
                                />
                                <InputError message={errors.file} className="mt-2" />
                            </div>` : ''}

                            <div className="flex items-center gap-4">
                                <PrimaryButton disabled={processing} className="bg-emerald-600 hover:bg-emerald-500">
                                    Save
                                </PrimaryButton>
                                <Link href={route('${mod.routePrefix}.index')} className="text-sm text-gray-600 hover:text-gray-900">
                                    Cancel
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
`;

const getEditTemplate = (mod) => `import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout';
import { Head, Link, useForm } from '@inertiajs/react';
import InputError from '@/Components/InputError';
import InputLabel from '@/Components/InputLabel';
import PrimaryButton from '@/Components/PrimaryButton';
import TextInput from '@/Components/TextInput';
import { FileText } from 'lucide-react';

export default function Edit({ record }) {
    const { data, setData, post, processing, errors } = useForm({
        _method: 'put',
        ${mod.fields.map(f => `${f.key}: record.${f.key} || '',`).join('\\n        ')}
        ${mod.hasFile ? `file: null,` : ''}
    });

    const submit = (e) => {
        e.preventDefault();
        post(route('${mod.routePrefix}.update', record.id));
    };

    return (
        <AuthenticatedLayout header="Edit ${mod.singular}">
            <Head title="Edit ${mod.singular}" />

            <div className="max-w-2xl mx-auto mt-6 px-4 sm:px-6 lg:px-8">
                <div className="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                    <div className="p-6 text-gray-900">
                        <form onSubmit={submit} className="space-y-6">
                            ${mod.fields.map(f => `<div>
                                <InputLabel htmlFor="${f.key}" value="${f.label}" />
                                <TextInput
                                    id="${f.key}"
                                    type="${f.type}"
                                    value={data.${f.key}}
                                    className="mt-1 block w-full"
                                    onChange={(e) => setData('${f.key}', e.target.value)}
                                    required={${f.key === 'name' || f.key === 'title' || f.key === 'hole_no' ? 'true' : 'false'}}
                                />
                                <InputError message={errors.${f.key}} className="mt-2" />
                            </div>`).join('\\n                            ')}
                            
                            ${mod.hasFile ? `<div>
                                <InputLabel htmlFor="file" value="Attachment (Leave blank to keep current)" />
                                {record.file_path && (
                                    <div className="mb-2">
                                        <a href={\`/storage/\${record.file_path}\`} target="_blank" className="text-emerald-600 hover:underline flex items-center text-sm">
                                            <FileText className="w-4 h-4 mr-1"/> Current Attachment
                                        </a>
                                    </div>
                                )}
                                <input
                                    id="file"
                                    type="file"
                                    onChange={(e) => setData('file', e.target.files[0])}
                                    className="mt-1 block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 border border-slate-200 rounded-md p-1"
                                    accept=".pdf,image/*"
                                />
                                <InputError message={errors.file} className="mt-2" />
                            </div>` : ''}

                            <div className="flex items-center gap-4">
                                <PrimaryButton disabled={processing} className="bg-emerald-600 hover:bg-emerald-500">
                                    Update
                                </PrimaryButton>
                                <Link href={route('${mod.routePrefix}.index')} className="text-sm text-gray-600 hover:text-gray-900">
                                    Cancel
                                </Link>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </AuthenticatedLayout>
    );
}
`;

const baseDir = path.join(__dirname, 'resources', 'js', 'Pages', 'Admin', 'Tournaments');
if (!fs.existsSync(baseDir)) {
    fs.mkdirSync(baseDir, { recursive: true });
}

modules.forEach(mod => {
    const modDir = path.join(baseDir, mod.name);
    if (!fs.existsSync(modDir)) {
        fs.mkdirSync(modDir, { recursive: true });
    }

    fs.writeFileSync(path.join(modDir, 'Index.jsx'), getIndexTemplate(mod));
    fs.writeFileSync(path.join(modDir, 'Create.jsx'), getCreateTemplate(mod));
    fs.writeFileSync(path.join(modDir, 'Edit.jsx'), getEditTemplate(mod));
});

console.log("React views generated successfully!");
