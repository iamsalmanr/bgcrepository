<?php
require __DIR__.'/vendor/autoload.php';
$app = require_once __DIR__.'/bootstrap/app.php';
$kernel = $app->make(Illuminate\Contracts\Console\Kernel::class);
$kernel->bootstrap();

$data = [
    'is_fees_data' => true,
    'membership_fees' => [
        ['category' => 'Serving Officers', 'entry' => '4000.00', 'monthly' => '500.00', 'green_non' => '200.00', 'green_other' => '100.00', 'caddie' => '100.00', 'ball_boy' => '70.00'],
        ['category' => 'Retired Officers', 'entry' => '5000.00', 'monthly' => '500.00', 'green_non' => '200.00', 'green_other' => '100.00', 'caddie' => '100.00', 'ball_boy' => '70.00'],
        ['category' => 'Civil Govt Officials (Serving/Retired)', 'entry' => '50,000.00', 'monthly' => '800.00', 'green_non' => '300.00', 'green_other' => '200.00', 'caddie' => '100.00', 'ball_boy' => '70.00'],
        ['category' => 'Civilian', 'entry' => '3 Lac', 'monthly' => '1000.00', 'green_non' => '1,000.00', 'green_other' => '400.00', 'caddie' => '100.00', 'ball_boy' => '70.00'],
        ['category' => 'Foreigners /Diplomats', 'entry' => '5 Lac', 'monthly' => '5000.00', 'green_non' => '1,000.00', 'green_other' => '800.00', 'caddie' => '600.00', 'ball_boy' => '200.00'],
        ['category' => 'Absentee Member (for defence officers only)', 'entry' => '-', 'monthly' => '25.00', 'green_non' => '-', 'green_other' => '-', 'caddie' => '-', 'ball_boy' => '-'],
        ['category' => 'Family Member (Svc/Retd)', 'entry' => '-', 'monthly' => '200.00 per family in addition to members subs', 'green_non' => '-', 'green_other' => '-', 'caddie' => '100.00', 'ball_boy' => '70.00'],
        ['category' => 'Family Member (Civ Govt)', 'entry' => '-', 'monthly' => '300.00 per family in addition to members subs', 'green_non' => '-', 'green_other' => '-', 'caddie' => '100.00', 'ball_boy' => '70.00'],
        ['category' => 'Family Member (Civilian)', 'entry' => '-', 'monthly' => '400.00 per family in addition to members subs', 'green_non' => '-', 'green_other' => '-', 'caddie' => '100.00', 'ball_boy' => '70.00'],
    ],
    'other_charges' => [
        ['category' => 'Regular Members', 'practice' => '100.00', 'tournament' => '200.00', 'trolley' => '50.00', 'driving' => '25.00', 'locker' => '150.00', 'remark' => ''],
        ['category' => 'Non Members', 'practice' => '300.00', 'tournament' => '500.00', 'trolley' => '100.00', 'driving' => '50.00', 'locker' => '0.00', 'remark' => ''],
        ['category' => 'Foreigners', 'practice' => '1000.00', 'tournament' => '2000.00', 'trolley' => '500.00', 'driving' => '100.00', 'locker' => '0.00', 'remark' => ''],
    ]
];

\App\Models\Page::where('slug', 'fees')->update(['content' => json_encode($data)]);
echo "Database seeded successfully!\n";
